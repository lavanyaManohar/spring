# University 

## Department Service 

##Get All 

http://localhost:8080/university/departments

http://localhost:8080/university/departments?number=1&numberOfElements=3

##Get One 

http://localhost:8080/university/departments/1

http://localhost:8080/university/departments/1212/



##Create / POST

http://localhost:8080/university/departments/

{
	"name" : "Arts Department"
}


##Update / PUT

http://localhost:8080//university/departments/3

{
	"name" : "Arts Department"
}