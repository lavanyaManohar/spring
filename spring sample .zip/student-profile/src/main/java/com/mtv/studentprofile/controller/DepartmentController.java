/**
 *
 */
package com.mtv.studentprofile.controller;

import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.mtv.studentprofile.domain.DepartmentDO;
import com.mtv.studentprofile.domain.DepartmentResponseResults;
import com.mtv.studentprofile.service.DepartmentService;

/**
 * @author VarathM
 *
 */

@RestController
@RequestMapping(path = "/university/departments")
public class DepartmentController extends BaseController {

	@Autowired
	DepartmentService service;

	@PostMapping
	@ResponseStatus(HttpStatus.CREATED)
	public DepartmentDO createDepartment(@RequestBody @Validated DepartmentDO department) throws Exception {
		return this.service.createDepartment(department.getName());
	}

	@GetMapping(path = "/{departmentId}")
	public DepartmentDO getDepartment(@PathVariable(value = "departmentId") Integer departmentId) {

		final DepartmentDO department = this.service.getDepartment(departmentId);
		if (department == null) {
			throw new NoSuchElementException("Department request with departmentId " + departmentId + " not found.");
		}
		return department;

	}

	@GetMapping
	public DepartmentResponseResults getDepartments(
			@RequestParam(required = false, name = "number", defaultValue = "0") Integer number,
			@RequestParam(required = false, name = "numberOfElements", defaultValue = "20") Integer numberOfElements) {

		return this.service.getDepartments(number, numberOfElements);

	}

	@PutMapping(path = "/{departmentId}")
	@ResponseStatus(HttpStatus.ACCEPTED)
	public DepartmentDO updateDepartment(@PathVariable(value = "departmentId") Integer departmentId,
			@RequestBody @Validated DepartmentDO departmentInput) {

		final DepartmentDO department = this.service.getDepartment(departmentId);
		if (department == null) {
			throw new NoSuchElementException("Department request with departmentId " + departmentId + " not found.");
		}
		return this.service.updateDepartment(department.getId(), departmentInput.getName());

	}

}
