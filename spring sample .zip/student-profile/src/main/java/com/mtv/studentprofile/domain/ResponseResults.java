package com.mtv.studentprofile.domain;

public class ResponseResults extends PageInformation {

}
