package com.mtv.studentprofile.service;

import java.util.Arrays;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mtv.studentprofile.StudentProfileApplication;

@Service
public class UniversityService {
	private final static Logger logger = LogManager.getLogger(StudentProfileApplication.class);
	private final StudentService studentService;
	private final StaffService staffService;
	private final DepartmentService departmentService;
	private final CourseService courseService;

	@Autowired
	public UniversityService(StudentService studentService, StaffService staffService,
			DepartmentService departmentService, CourseService courseService) {
		this.studentService = studentService;
		this.staffService = staffService;
		this.departmentService = departmentService;
		this.courseService = courseService;
	}

	public void setupUniversity() {
		logger.debug("Creating University");

		logger.debug("Creating Departments");
		Arrays.asList(UniversityHelper.departments).forEach(department -> {
			this.departmentService.createDepartment(null, department);
		});

		logger.debug("Creating Courses");
		Arrays.asList(UniversityHelper.courses).forEach(course -> {
			this.courseService.createCourse(course, null, null);
		});

		/**
		 * logger.debug("Creating staffs"); final List<Department> departmentList = new
		 * LinkedList<>(); for (int i = 0; i < 20; i++) { final Staff headStaff =
		 * this.staffService.createStaff(UniversityHelper.getRandomFirstName(),
		 * UniversityHelper.getRandomLastName());
		 *
		 * final Department department =
		 * this.departmentService.createDepartment(headStaff,
		 * UniversityHelper.getRandomDepartmentName()); departmentList.add(department);
		 *
		 * }
		 *
		 * for (int deptId = 0; deptId < departmentList.size(); deptId++) { final
		 * Department department = departmentList.get(deptId); for (int i = 0; i < 10;
		 * i++) {
		 *
		 * final Staff courseStaff =
		 * this.staffService.createStaff(UniversityHelper.getRandomFirstName(),
		 * UniversityHelper.getRandomLastName());
		 *
		 * this.courseService.createCourse(UniversityHelper.getRandomCourseName(),
		 * courseStaff, department);
		 *
		 * }
		 *
		 * }
		 *
		 * logger.debug("Creating students");
		 *
		 * for (int i = 0; i < 1000; i++) {
		 * this.studentService.createStudent(UniversityHelper.getRandomFirstName(),
		 * UniversityHelper.getRandomLastName(), UniversityHelper.getRandomAge(),
		 * UniversityHelper.getRandomFullTime()); }
		 */
		logger.debug("Total Department in University : {} ", this.departmentService.total());
		logger.debug("Total Staff in University : {} ", this.staffService.total());
		logger.debug("Total Course in University : {} ", this.courseService.total());
		logger.debug("Total Students in University : {} ", this.studentService.total());

		logger.debug("University setup process completed");
	}
}
