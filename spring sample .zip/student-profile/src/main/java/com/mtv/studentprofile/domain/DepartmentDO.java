package com.mtv.studentprofile.domain;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

public class DepartmentDO {
	private Integer id;

	@Size(min = 6, max = 50)
	@NotNull
	private String name;

	@Size(max = 2000)
	private String description;

	public String getDescription() {
		return this.description;
	}

	public Integer getId() {
		return this.id;
	}

	public String getName() {
		return this.name;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public void setName(String name) {
		this.name = name;
	}
}
