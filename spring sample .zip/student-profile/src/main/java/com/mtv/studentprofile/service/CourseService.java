package com.mtv.studentprofile.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mtv.studentprofile.entity.Course;
import com.mtv.studentprofile.entity.Department;
import com.mtv.studentprofile.entity.Staff;
import com.mtv.studentprofile.repository.CourseRepository;

@Service
public class CourseService {

	private final CourseRepository courseRepository;

	@Autowired
	public CourseService(CourseRepository courseRepository) {
		this.courseRepository = courseRepository;
	}

	public Course createCourse(String name, Staff instructor, Department department) {

		final Integer credits = 100;

		final Course course = new Course(name, credits, instructor, department);
		return this.courseRepository.save(course);
	}

	public long total() {
		return this.courseRepository.count();
	}

}
