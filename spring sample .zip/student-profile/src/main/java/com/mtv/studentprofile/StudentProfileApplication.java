package com.mtv.studentprofile;

import java.util.Calendar;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.mtv.studentprofile.service.UniversityService;

@SpringBootApplication
public class StudentProfileApplication implements CommandLineRunner {

	private final static Logger logger = LogManager.getLogger(StudentProfileApplication.class);

	public static void main(String[] args) {
		SpringApplication.run(StudentProfileApplication.class, args);

		final String appStartTime = Calendar.getInstance().getTime().toString();
		final String appName = "Students profile application";

		logger.info("App : {}, Started on : {} ", appName, appStartTime);
		logger.debug("*****************************************************************************");

	}

	@Autowired
	UniversityService universityService;

	@Override
	public void run(String... args) throws Exception {
		logger.debug("********************************** startup tasks *******************************************");
		this.universityService.setupUniversity();

	}

}
