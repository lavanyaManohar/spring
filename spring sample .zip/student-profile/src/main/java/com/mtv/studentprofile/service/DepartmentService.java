package com.mtv.studentprofile.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.mtv.studentprofile.domain.DepartmentDO;
import com.mtv.studentprofile.domain.DepartmentResponseResults;
import com.mtv.studentprofile.entity.Department;
import com.mtv.studentprofile.entity.Staff;
import com.mtv.studentprofile.error.ApplicationException;
import com.mtv.studentprofile.mapper.DepartmentToDOMapper;
import com.mtv.studentprofile.repository.DepartmentRepository;

@Service
public class DepartmentService {

	DepartmentRepository departmentRepository;
	DepartmentToDOMapper departmentToDOMapper;

	@Autowired
	public DepartmentService(DepartmentRepository departmentRepository, DepartmentToDOMapper departmentToDOMapper) {
		this.departmentRepository = departmentRepository;
		this.departmentToDOMapper = departmentToDOMapper;
	}

	private DepartmentDO convert(Department department) {
		return this.departmentToDOMapper.convert(department);
	}

	private List<DepartmentDO> convert(List<Department> departmentsIn) {
		final List<DepartmentDO> departmentsOut = new ArrayList<>();
		if (CollectionUtils.isNotEmpty(departmentsIn)) {
			departmentsIn.forEach(department -> {
				departmentsOut.add(this.convert(department));
			});
			return departmentsOut;
		}
		return departmentsOut;
	}

	public Department createDepartment(Staff chair, String departmentName) {
		final Department department = new Department(departmentName, chair);
		return this.departmentRepository.save(department);
	}

	public DepartmentDO createDepartment(String name) throws Exception {

		final Department departmentCheck = this.departmentRepository.findByNameIgnoreCase(name);
		if (null == departmentCheck) {
			final Department department = new Department(name, null);
			return this.convert(this.departmentRepository.save(department));
		}
		throw new ApplicationException(HttpStatus.CONFLICT, "Department name (" + name + ") already exists.");

	}

	public DepartmentDO getDepartment(Integer departmentId) {

		final Optional<Department> fetchedValue = this.departmentRepository.findById(departmentId);

		if (fetchedValue.isPresent()) {
			return this.convert(fetchedValue.get());
		}

		return null;
	}

	public DepartmentResponseResults getDepartments(Integer number, Integer numberOfElements) {
		final PageRequest pageable = new PageRequest(number, numberOfElements, Sort.Direction.ASC, "name");
		final Page<Department> departments = this.departmentRepository.findAll(pageable);
		final DepartmentResponseResults response = new DepartmentResponseResults();

		response.setContents(this.convert(departments.getContent()));
		response.setPageable(departments.getPageable());
		response.setSize(departments.getSize());
		response.setNumber(departments.getNumber());
		response.setNumberOfElements(departments.getNumberOfElements());
		response.setSort(departments.getSort());
		response.setTotalElements(departments.getTotalElements());
		response.setTotalPages(departments.getTotalPages());

		return response;

	}

	public long total() {
		return this.departmentRepository.count();
	}

	public DepartmentDO updateDepartment(Integer departmentId, String name) {

		final Optional<Department> fetchedValue = this.departmentRepository.findById(departmentId);

		if (fetchedValue.isPresent()) {
			final Department department = fetchedValue.get();

			department.setName(name);

			return this.convert(this.departmentRepository.saveAndFlush(department));
		}

		return null;
	}

}
