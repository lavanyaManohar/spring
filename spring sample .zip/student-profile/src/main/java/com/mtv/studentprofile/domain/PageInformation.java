package com.mtv.studentprofile.domain;

import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;

public class PageInformation {
	private Pageable pageable;

	private int number;

	private int numberOfElements;

	private int size;
	private Sort sort;
	private long totalElements;
	private int totalPages;

	public int getNumber() {
		return this.number;
	}

	public int getNumberOfElements() {
		return this.numberOfElements;
	}

	public Pageable getPageable() {
		return this.pageable;
	}

	public int getSize() {
		return this.size;
	}

	public Sort getSort() {
		return this.sort;
	}

	public long getTotalElements() {
		return this.totalElements;
	}

	public int getTotalPages() {
		return this.totalPages;
	}

	public void setNumber(int number) {
		this.number = number;
	}

	public void setNumberOfElements(int numberOfElements) {
		this.numberOfElements = numberOfElements;
	}

	public void setPageable(Pageable pageable) {
		this.pageable = pageable;
	}

	public void setSize(int size) {
		this.size = size;
	}

	public void setSort(Sort sort) {
		this.sort = sort;
	}

	public void setTotalElements(long totalElements) {
		this.totalElements = totalElements;
	}

	public void setTotalPages(int totalPages) {
		this.totalPages = totalPages;
	}

}
