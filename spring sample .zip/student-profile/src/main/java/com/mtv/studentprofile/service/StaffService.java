package com.mtv.studentprofile.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mtv.studentprofile.entity.Person;
import com.mtv.studentprofile.entity.Staff;
import com.mtv.studentprofile.repository.StaffRepository;

@Service
public class StaffService {

	private final StaffRepository staffRepository;

	@Autowired
	public StaffService(StaffRepository staffRepository) {
		this.staffRepository = staffRepository;
	}

	public Staff createStaff(String firstName, String lastName) {

		final Person member = new Person(firstName, lastName);
		final Staff staff = new Staff(member);
		return this.staffRepository.save(staff);
	}

	public long total() {
		return this.staffRepository.count();
	}

}
