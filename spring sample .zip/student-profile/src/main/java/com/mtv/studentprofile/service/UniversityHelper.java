package com.mtv.studentprofile.service;

import java.util.Random;

public class UniversityHelper {

	static final String[] courses = { "Accounting", "Administrative Assistant or Secretary", "Art", "Auto Mechanics",
			"Beauty Care", "Bookkeeping", "Business Management", "Canine Specialist", "Child Day Care Management",
			"Child Psychology", "Computer Programming", "Computer Training", "Conservation or Environmental Sciences",
			"Contractor or Construction Management", "Cooking & Catering", "Creative Writing", "Criminal Justice",
			"Dental Assistant", "Drafting with AutoCAD®", "Drug & Alcohol Treatment Specialist",
			"Early Childhood Education", "Electrician", "English as a Second Language",
			"Fashion Merchandising and Design", "Fitness & Nutrition", "Florist or Floral Design", "Forensic Science",
			"French as a Second Language", "Funeral Service Education", "Gardening & Landscaping", "Health Care Aide",
			"High School Program", "Home Inspector", "Hotel & Restaurant Management", "Interior Decorating",
			"Legal Assistant or Paralegal", "Medical Billing Specialist", "Medical Office Assistant",
			"Medical Transcriptionist", "Motorcycle or ATV Repair", "Natural Health Consultant", "PC Repair",
			"Pharmacy Assistant", "Photography", "Physical Therapy Aide", "Plumbing", "Private Investigator",
			"Professional Locksmith", "Psychology or Social Work", "Real Estate Appraiser", "Relaxation Therapist",
			"Security or Police Sciences", "Sewing & Dressmaking", "Small Engine Repair",
			"Spanish as a Second Language", "Start Your Own Business", "Teacher Aide", "Travel & Tourism",
			"Veterinary Assistant", "Video Game Design", "Wedding Consultant", "Writing Stories for Children",
			"Accounting & Finance", "Aeronautical & Manufacturing Engineering", "Agriculture & Forestry",
			"American Studies", "Anatomy & Physiology", "Anthropology", "Archaeology", "Architecture", "Art & Design",
			"Aural & Oral Sciences", "Biological Sciences", "Building", "Business & Management Studies",
			"Celtic Studies", "Chemical Engineering", "Chemistry", "Civil Engineering", "Classics & Ancient History",
			"Communication & Media Studies", "Complementary Medicine", "Computer Science", "Counselling",
			"Creative Writing", "Criminology", "Dentistry", "Drama, Dance & Cinematics", "East & South Asian Studies",
			"Economics", "Education", "Electrical & Electronic Engineering", "English", "Fashion", "Film Making",
			"Food Science", "Forensic Science", "French", "Geography & Environmental Sciences", "Geology",
			"General Engineering", "German", "History", "History of Art, Architecture & Design",
			"Hospitality, Leisure, Recreation & Tourism", "Iberian Languages or Hispanic Studies", "Italian",
			"Land & Property Management", "Law", "Librarianship & Information Management", "Linguistics", "Marketing",
			"Materials Technology", "Mathematics", "Mechanical Engineering", "Medical Technology", "Medicine",
			"Middle Eastern & African Studies", "Music", "Nursing", "Occupational Therapy",
			"Optometry, Ophthalmology & Orthoptics", "Pharmacology & Pharmacy", "Philosophy", "Physics and Astronomy",
			"Physiotherapy", "Politics", "Psychology", "Robotics", "Russian & East European Languages", "Social Policy",
			"Social Work", "Sociology", "Sports Science", "Theology & Religious Studies",
			"Town & Country Planning and Landscape Design", "Veterinary Medicine", "Youth Work" };

	static final String[] departments = { "Aeronautics & Astronautics", "Anesthesia", "Anthropology", "Applied Physics",
			"Art & Art History", "Biochemistry", "Bioengineering", "Biology", "Business", "Cardiothoracic Surgery",
			"Chemical Engineering", "Chemistry", "Civil & Environmental Engineering", "Classics", "Communication",
			"Comparative Literature", "Comparative Medicine", "Computer Science", "Dermatology",
			"Developmental Biology", "East Asian Languages and Cultures", "Economics", "Electrical Engineering",
			"Energy Resources Engineering", "English", "French and Italian", "Genetics", "Geological Sciences",
			"Geophysics", "German Studies", "Health Research & Policy", "History", "Humanities & Sciences",
			"Iberian & Latin American Cultures", "Law School", "Linguistics", "Management Science & Engineering",
			"Materials Science & Engineering", "Mathematics", "Mechanical Engineering", "Medicine",
			"Microbiology & Immunology", "Molecular & Cellular Physiology", "Music", "Neurobiology",
			"Neurology & Neurological Sciences", "Neurosurgery", "Obstetrics and Gynecology", "Ophthalmology",
			"Orthopaedic Surgery", "Otolaryngology (Head and Neck Surgery)", "Pathology", "Pediatrics", "Philosophy",
			"Physics", "Political Science", "Psychiatry and Behavioral Sciences", "Psychology", "Radiation Oncology",
			"Radiology", "Religious Studies", "Slavic Languages and Literature", "Sociology", "Statistics",
			"Structural Biology", "Surgery", "Theater and Performance Studies", "Urology" };

	static final String[] names = { "smith", "brown", "miller", "johnson", "jones", "davis", "williams", "wilson",
			"clark", "taylor", "john", "william", "james", "george", "henry", "thomas", "charles", "joseph", "samuel",
			"david", "mary", "sarah", "elizabeth", "martha", "margaret", "nancy", "ann", "jane", "eliza", "catherine",
			"john", "william", "james", "thomas", "george", "joseph", "samuel", "henry", "david", "daniel" };

	public static int getRandomAge() {
		return getRandomNumberInRange(17, 20);
	}

	public static String getRandomCourseName() {
		return courses[getRandomNumberInRange(0, courses.length - 1)];
	}

	public static String getRandomDepartmentName() {

		return departments[getRandomNumberInRange(0, departments.length - 1)];
	}

	public static String getRandomFirstName() {
		return names[getRandomNumberInRange(0, names.length - 1)];

	}

	public static boolean getRandomFullTime() {
		final int range = getRandomNumberInRange(0, 1);
		return range == 1 ? true : false;
	}

	public static String getRandomLastName() {
		return names[getRandomNumberInRange(0, names.length - 1)];

	}

	private static int getRandomNumberInRange(int min, int max) {
		if (min >= max) {
			min = max;
		}

		final Random r = new Random();
		return r.nextInt(max - min + 1) + min;
	}

	public static void main(String[] args) {

		for (int i = 0; i < 100; i++) {

			final String firstName = getRandomFirstName();
			final String lastName = getRandomLastName();

			final int age = getRandomAge();
			System.out.println(firstName + " " + lastName + " " + age + " " + getRandomFullTime());
		}

	}
}
