package com.mtv.studentprofile.controller;

import static org.springframework.http.HttpStatus.INTERNAL_SERVER_ERROR;

import java.sql.SQLException;
import java.util.NoSuchElementException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.mtv.studentprofile.error.ApplicationException;
import com.mtv.studentprofile.error.ApplicationRunTimeException;

@ControllerAdvice
@RestControllerAdvice
public class ServiceErrorAdvice {

	private final static Logger logger = LogManager.getLogger(ServiceErrorAdvice.class);

	private ResponseEntity<String> error(HttpStatus status, Exception e) {
		logger.error("{} Exception  :  {} ", status.toString(), e);
		return ResponseEntity.status(status).body(e.getMessage());
	}

	@ResponseStatus(HttpStatus.BAD_REQUEST)
	@ExceptionHandler(ApplicationException.class)
	public ResponseEntity<String> handle(ApplicationException ex) {
		logger.error("ApplicationException Exception : {} ", ex.getMessage());
		return this.error(HttpStatus.BAD_REQUEST, ex);

	}

	@ResponseStatus(HttpStatus.BAD_REQUEST)
	@ExceptionHandler(ApplicationRunTimeException.class)
	public ResponseEntity<String> handle(ApplicationRunTimeException ex) {
		logger.error("ApplicationRunTimeException Exception : {} ", ex.getMessage());
		return this.error(HttpStatus.BAD_REQUEST, ex);

	}

	@ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
	@ExceptionHandler({ Exception.class, SQLException.class, NullPointerException.class })
	public ResponseEntity<String> handle(Exception e) {
		logger.error("Exception : {} ", e.getMessage());
		return this.error(INTERNAL_SERVER_ERROR, e);
	}

	@ResponseStatus(HttpStatus.BAD_REQUEST)
	@ExceptionHandler(MethodArgumentNotValidException.class)
	public ResponseEntity<String> handle(MethodArgumentNotValidException ex) {
		logger.error("MethodArgumentNotValidException Exception : {} ", ex.getMessage());
		return this.error(HttpStatus.BAD_REQUEST, ex);

	}

	@ResponseStatus(HttpStatus.BAD_REQUEST)
	@ExceptionHandler(NoSuchElementException.class)
	public ResponseEntity<String> handle(NoSuchElementException ex) {
		logger.error("NoSuchElementException Exception : {} ", ex.getMessage());
		return this.error(HttpStatus.BAD_REQUEST, ex);

	}

}
