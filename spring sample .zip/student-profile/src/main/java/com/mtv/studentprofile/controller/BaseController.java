package com.mtv.studentprofile.controller;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class BaseController {
	private final static Logger logger = LogManager.getLogger(BaseController.class);

}
