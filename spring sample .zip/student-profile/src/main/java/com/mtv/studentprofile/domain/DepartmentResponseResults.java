package com.mtv.studentprofile.domain;

import java.util.List;

public class DepartmentResponseResults extends ResponseResults {

	private List<DepartmentDO> contents;

	public List<DepartmentDO> getContents() {
		return this.contents;
	}

	public void setContents(List<DepartmentDO> data) {
		this.contents = data;

	}

}
