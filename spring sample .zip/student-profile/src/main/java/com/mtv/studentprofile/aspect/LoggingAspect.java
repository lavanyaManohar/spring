package com.mtv.studentprofile.aspect;

import java.time.Duration;
import java.time.LocalTime;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;

//@Aspect
//@Component
public class LoggingAspect {

	private final static Logger logger = LogManager.getLogger(LoggingAspect.class);

	@Around("execution(* com.mtv.studentprofile.controller.DepartmentController.*(..))")
	public void logAroundAllMethods(ProceedingJoinPoint joinPoint) throws Throwable {
		final LocalTime start = LocalTime.now();

		try {
			joinPoint.proceed();
		} finally {
			// Do Something useful, If you have
		}
		final LocalTime end = LocalTime.now();

		logger.trace("[Execution Time] : " + joinPoint.getSignature().getName() + ": "
				+ Duration.between(start, end).abs() + " ms.");
	}

}
