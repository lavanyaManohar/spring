package com.mtv.studentprofile.error;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;

public class ApplicationException extends Exception {
	/**
	 *
	 */
	private static final long serialVersionUID = 1L;
	private final static Logger logger = LogManager.getLogger(ApplicationException.class);

	public ApplicationException(HttpStatus status, String errorMessage) {
		super(errorMessage);
		logger.error("{} ApplicationException  :  {} ", status.toString(), errorMessage);
	}

	public ApplicationException(String errorMessage) {
		super(errorMessage);
		logger.error("ApplicationException  :  {} ", errorMessage);
	}
}
