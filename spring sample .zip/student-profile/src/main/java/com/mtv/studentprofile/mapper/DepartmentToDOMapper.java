package com.mtv.studentprofile.mapper;

import org.dozer.DozerBeanMapper;
import org.dozer.loader.api.BeanMappingBuilder;
import org.springframework.stereotype.Service;

import com.mtv.studentprofile.domain.DepartmentDO;
import com.mtv.studentprofile.entity.Department;

@Service
public class DepartmentToDOMapper {

	DozerBeanMapper mapper;

	BeanMappingBuilder builder = new BeanMappingBuilder() {

		@Override
		protected void configure() {
			this.mapping(Department.class, DepartmentDO.class).fields("id", "id").fields("name", "name")
					.fields("description", "description");

		}
	};

	public DepartmentToDOMapper() {
		this.mapper = new DozerBeanMapper();
		this.mapper.addMapping(this.builder);
	}

	public DepartmentDO convert(Department department) {
		return this.mapper.map(department, DepartmentDO.class);
	}

}
