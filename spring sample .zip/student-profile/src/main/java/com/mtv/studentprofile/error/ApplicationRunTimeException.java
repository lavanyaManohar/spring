package com.mtv.studentprofile.error;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class ApplicationRunTimeException extends RuntimeException {
	/**
	 *
	 */
	private static final long serialVersionUID = 1L;
	private final static Logger logger = LogManager.getLogger(ApplicationRunTimeException.class);

	public ApplicationRunTimeException(String errorMessage, Throwable err) {
		super(errorMessage, err);
		logger.error("ApplicationRunTimeException  :  {} - {} ", errorMessage, err.getMessage());
	}
}
