package com.mtv.studentprofile.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mtv.studentprofile.entity.Person;
import com.mtv.studentprofile.entity.Student;
import com.mtv.studentprofile.repository.StudentRepository;

@Service
public class StudentService {

	private final StudentRepository studentRepository;

	@Autowired
	public StudentService(StudentRepository studentRepository) {
		this.studentRepository = studentRepository;
	}

	public void createStudent(String firstName, String lastName, int age, boolean fullTime) {

		final Person attendee = new Person(firstName, lastName);
		final Student student = new Student(attendee, fullTime, age);
		this.studentRepository.save(student);
	}

	public long total() {
		return this.studentRepository.count();
	}

}
