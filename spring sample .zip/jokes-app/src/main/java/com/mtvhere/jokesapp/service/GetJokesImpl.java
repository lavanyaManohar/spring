package com.mtvhere.jokesapp.service;

import guru.springframework.norris.chuck.ChuckNorrisQuotes;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class GetJokesImpl implements GetJoke {

    private final ChuckNorrisQuotes quotes;

    @Autowired
    public GetJokesImpl() {
        this.quotes = new ChuckNorrisQuotes();
    }

    @Override
    public String getJoke() {
        return this.quotes.getRandomQuote();
    }
}
