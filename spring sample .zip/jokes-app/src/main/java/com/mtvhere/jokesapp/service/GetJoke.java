package com.mtvhere.jokesapp.service;

public interface GetJoke {
    public String getJoke();
}
