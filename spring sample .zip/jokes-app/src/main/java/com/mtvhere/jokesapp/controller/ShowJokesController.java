package com.mtvhere.jokesapp.controller;

import com.mtvhere.jokesapp.service.GetJoke;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class ShowJokesController {

    private final GetJoke jokes;

    public ShowJokesController(final GetJoke jokes) {
        this.jokes = jokes;
    }

    @RequestMapping({"/", ""})
    public String showJoke(final Model model) {
        model.addAttribute("joke", this.jokes.getJoke());

        return "joke";
    }
}
