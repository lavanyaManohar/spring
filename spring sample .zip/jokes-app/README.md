# spring web Jokes App
spring-projects

## Added External dependency from mvnrepository 
https://mvnrepository.com/artifact/guru.springframework/chuck-norris-for-actuator/0.0.2

URL : http://localhost:8080/