package com.mtvhere.spring5webapp.domain;

public class Author {
}
